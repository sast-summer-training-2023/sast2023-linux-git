#pragma once

namespace Ripes {
namespace Fonts {

constexpr auto monospace = "Inconsolata";

} // namespace Fonts
} // namespace Ripes
