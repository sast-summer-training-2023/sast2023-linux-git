#pragma once

#include <QString>

namespace Ripes {
QString getRipesVersion();
}
