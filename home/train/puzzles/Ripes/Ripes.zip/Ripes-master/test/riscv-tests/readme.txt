The tests in this directory were generated and modified from the riscv-tests repository. They cover basic conformance of instructions to the specification.

These tests have been modified by GitHub user TheThirdOne
https://github.com/TheThirdOne/rars/tree/master/test/riscv-tests
